package com.example.lbltakefive.activity;

import androidx.appcompat.app.AppCompatActivity;
import android.accounts.Account;
import android.accounts.AccountManager;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Environment;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import com.example.lbltakefive.Databases.DatabaseHelper;
import com.example.lbltakefive.R;
import com.example.lbltakefive.Takefivepage;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.util.Properties;
import java.util.regex.Pattern;
import javax.activation.DataHandler;
import javax.activation.FileDataSource;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;


public class Succefulactivity extends AppCompatActivity {
    String possibleEmail;
    DatabaseHelper databaseHelper;
    String username = "";
    String password = "";


    Button button,exit;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_succefulactivity);
        button = findViewById(R.id.add_new);
        exit = findViewById(R.id.exit);
        databaseHelper = new DatabaseHelper(this);



        Pattern emailPattern = Patterns.EMAIL_ADDRESS; // API level 8+
        Account[] accounts = AccountManager.get(this).getAccounts();
        for (Account account : accounts) {
            if (emailPattern.matcher(account.name).matches()) {
                possibleEmail = account.name;
            }
        }

        exit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               createPdf();
               new Sendmaial().execute();
                finish();

            }
        });
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Succefulactivity.this, Takefivepage.class);
                startActivity(intent);
            }
        });
    }
    public static class Sendmaial extends AsyncTask<String,Integer,Integer> {


        @Override
        protected Integer doInBackground(String... strings) {
            final String username = "subhasis.mondol@pupalinks.com";
            final String password = "9735518364@subha";

            Properties props = new Properties();
            props.put("mail.smtp.auth", "true");
            props.put("mail.smtp.starttls.enable", "true");
            props.put("mail.smtp.host", "smtpout.secureserver.net");
            props.put("mail.smtp.port", "587");

            Session session = Session.getInstance(props,
                    new javax.mail.Authenticator() {
                        protected PasswordAuthentication getPasswordAuthentication() {
                            return new PasswordAuthentication(username, password);
                        }
                    });
            try {
                Message message = new MimeMessage(session);
                message.setFrom(new InternetAddress("subhasis.mondol@pupalinks.com"));
                message.setRecipients(Message.RecipientType.TO,
                        InternetAddress.parse("buddhadev.maity@pupalinks.com"));
                message.setSubject("Testing Subject");
                message.setText("Dear Mail Crawler,"
                        + "\n\n No spam to my email, please!");

                MimeBodyPart messageBodyPart;

                Multipart multipart = new MimeMultipart();

                messageBodyPart = new MimeBodyPart();
                String filename="MyBackUp.csv";
                File filelocation = new File(Environment.getExternalStorageDirectory().getAbsolutePath(), filename);
                String fileName = "newFile";
                FileDataSource source =  new FileDataSource(filelocation);
                messageBodyPart.setDataHandler(new DataHandler(source));
                messageBodyPart.setFileName(fileName);
                multipart.addBodyPart(messageBodyPart);

                message.setContent(multipart);

                Transport.send(message);

                System.out.println("Done");

            } catch (MessagingException e) {
                throw new RuntimeException(e);
            }
            return 1;
        }
    }
//    private void sendEmail() throws AddressException {
//        String filename="MyBackUp.csv";
//        File filelocation = new File(Environment.getExternalStorageDirectory().getAbsolutePath(), filename);
//        final Uri path = Uri.fromFile(filelocation);
//
//
//        new Thread(new Runnable() {
//
//            @Override
//            public void run() {
//                try {
//                    Properties props = new Properties();
//                    props.put("mail.smtp.auth", "true");
//                    props.put("mail.smtp.starttls.enable", "true");
//                    props.put("mail.smtp.host", "smtpout.secureserver.net");
//                    props.put("mail.smtp.port", "25");
//
//                    Session session = Session.getInstance(props,
//                            new javax.mail.Authenticator() {
//                                protected javax.mail.PasswordAuthentication getPasswordAuthentication() {
//                                    return new javax.mail.PasswordAuthentication(
//                                            username, password);
//                                }
//                            });
//                    javax.mail.Message message = new MimeMessage(session);
//                    message.setFrom(new InternetAddress("subhasis.mondol@pupalinks.com"));
//                    message.setRecipients(MimeMessage.RecipientType.TO,
//                            InternetAddress.parse("buddhadev.maity@pupalinks.com"));
//                    message.setSubject("email");
//                    message.setText("HI,"
//                            + "\n\n great");
//                    if (!"".equals(path)) {
//                        Multipart _multipart = new MimeMultipart();
//                        BodyPart messageBodyPart = new MimeBodyPart();
//                        FileDataSource source = new FileDataSource(String.valueOf(path));
//
//                        messageBodyPart.setDataHandler(new DataHandler((javax.activation.DataSource) source));
//                        messageBodyPart.setFileName(String.valueOf(path));
//
//                        _multipart.addBodyPart(messageBodyPart);
//                        ((MimeMessage) message).setContent(_multipart);
//                    }
//                    Transport.send(message);
//                    System.out.println("Done");
//                } catch (MessagingException e) {
//                    throw new RuntimeException(e);
//                }
//            }
//        }).start();

//        Properties properties = new Properties();
//        properties.put("mail.smtp.auth", "true");
//        properties.put("mail.smtp.starttls.enable", "true");
//        properties.put("mail.smtp.host", "smtpout.secureserver.net");
//        properties.put("mail.smtp.port", "587");
//        Session session = Session.getDefaultInstance(properties,new javax.mail.Authenticator(){
//            protected javax.mail.PasswordAuthentication getPasswordAuthentication() {
//                return new javax.mail.PasswordAuthentication(
//                        username, password);
//            }
//        });
//
//        Intent emailIntent = new Intent(Intent.ACTION_SEND);
//
//        emailIntent .setType("vnd.android.cursor.dir/email");
//        String to[] = {"adityasengupta2010@gmail.com"};
//        emailIntent .putExtra(Intent.EXTRA_EMAIL, to);
//
//        emailIntent .putExtra(Intent.EXTRA_STREAM, path);
//
//        emailIntent .putExtra(Intent.EXTRA_SUBJECT, "Subject");
//        startActivity(Intent.createChooser(emailIntent , "Send email..."));
 //   }

    private void createPdf() {
        SQLiteDatabase sqLiteDatabase = databaseHelper.getReadableDatabase();
        Cursor c;
        try {
            c = sqLiteDatabase.rawQuery("select * from Employee", null);
            int rowcount;
            int colcount;
            File sdCardDir = Environment.getExternalStorageDirectory();
            String filename = "MyBackUp.csv";
            // the name of the file to export with
            File saveFile = new File(sdCardDir, filename);
            FileWriter fw = new FileWriter(saveFile);

            BufferedWriter bw = new BufferedWriter(fw);
            rowcount = c.getCount();
            colcount = c.getColumnCount();
            if (rowcount > 0) {
                c.moveToFirst();

                for (int i = 0; i < colcount; i++) {
                    if (i != colcount - 1) {

                        bw.write(c.getColumnName(i) + ",");

                    } else {

                        bw.write(c.getColumnName(i));

                    }
                }
                bw.newLine();

                for (int i = 0; i < rowcount; i++) {
                    c.moveToPosition(i);

                    for (int j = 0; j < colcount; j++) {
                        if (j != colcount - 1)
                            bw.write(c.getString(j) + ",");
                        else
                            bw.write(c.getString(j));
                    }
                    bw.newLine();
                }
                bw.flush();

            }
        } catch (Exception ex) {
            if (sqLiteDatabase.isOpen()) {
                sqLiteDatabase.close();

            }

        }
    }


}
